package com.example.usodeaudio;

import androidx.appcompat.app.AppCompatActivity;

import android.media.MediaParser;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity2 extends AppCompatActivity {
    MediaPlayer reproductor;
    ImageButton animal1,animal2,animal3,animal4,animal5,
                animal6,animal7,animal8,animal9,animal10;
    TextView Estatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main2);

        Estatus = findViewById(R.id.txtestatus);
        animal1 = findViewById(R.id.btnanimal1);
        animal1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity2.this,R.raw.rabbit);
                reproductor.start();
                Estatus.setText("Reproduciendo conejo");
            }
        });
        animal2 = findViewById(R.id.btnanimal2);
        animal2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity2.this,R.raw.dolphin);
                reproductor.start();
                Estatus.setText("Reproduciendo delfin");
            }
        });
        animal3 = findViewById(R.id.btnanimal3);
        animal3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity2.this,R.raw.cat);
                reproductor.start();
                Estatus.setText("Reproduciendo gato");
            }
        });
        animal4 = findViewById(R.id.btnanimal4);
        animal4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity2.this,R.raw.iguana);
                reproductor.start();
                Estatus.setText("Reproduciendo iguana");
            }
        });
        animal5 = findViewById(R.id.btnanimal5);
        animal5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity2.this,R.raw.lion);
                reproductor.start();
                Estatus.setText("Reproduciendo leon");
            }
        });
        animal6 = findViewById(R.id.btnanimal6);
        animal6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity2.this,R.raw.dog);
                reproductor.start();
                Estatus.setText("Reproduciendo perro");
            }
        });
        animal7 = findViewById(R.id.btnanimal7);
        animal7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity2.this,R.raw.elephant);
                reproductor.start();
                Estatus.setText("Reproduciendo elefante");
            }
        });
        animal8 = findViewById(R.id.btnanimal8);
        animal8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity2.this,R.raw.fox);
                reproductor.start();
                Estatus.setText("Reproduciendo zorro");
            }
        });
        animal9 = findViewById(R.id.btnanimal9);
        animal9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity2.this,R.raw.giraffe);
                reproductor.start();
                Estatus.setText("Reproduciendo jirafa");
            }
        });
        animal10 = findViewById(R.id.btnanimal10);
        animal10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity2.this,R.raw.chicken);
                reproductor.start();
                Estatus.setText("Reproduciendo pollo");
            }
        });

    }

    public void DetenerReproductor(){
        if(reproductor!=null){
            if(reproductor.isPlaying()){
                reproductor.release();
                reproductor = null;
            }
        }
    }
}