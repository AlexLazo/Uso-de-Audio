package com.example.usodeaudio;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.TextView;

public class MainActivity3 extends AppCompatActivity {
    MediaPlayer reproductor;
    ImageButton animal1,animal2,animal3,animal4,animal5,
                animal6,animal7,animal8,animal9,animal10;
    TextView Estatuss;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main3);
        Estatuss = findViewById(R.id.txtestatuss);
        animal1 = findViewById(R.id.imageButton);
        animal1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity3.this,R.raw.cabra);
                reproductor.start();
                Estatuss.setText("Reproduciendo cabra");
            }
        });
        animal2 = findViewById(R.id.imageButton2);
        animal2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity3.this,R.raw.cerdo);
                reproductor.start();
                Estatuss.setText("Reproduciendo cerdo");
            }
        });
        animal3 = findViewById(R.id.imageButton3);
        animal3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity3.this,R.raw.cocodrilo);
                reproductor.start();
                Estatuss.setText("Reproduciendo cocodrilo");
            }
        });
        animal4 = findViewById(R.id.imageButton4);
        animal4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity3.this,R.raw.foca);
                reproductor.start();
                Estatuss.setText("Reproduciendo foca");
            }
        });
        animal5 = findViewById(R.id.imageButton5);
        animal5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity3.this,R.raw.koala);
                reproductor.start();
                Estatuss.setText("Reproduciendo koala");
            }
        });
        animal6 = findViewById(R.id.imageButton6);
        animal6.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity3.this,R.raw.mapache);
                reproductor.start();
                Estatuss.setText("Reproduciendo mapache");
            }
        });
        animal7 = findViewById(R.id.imageButton7);
        animal7.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity3.this,R.raw.vaca);
                reproductor.start();
                Estatuss.setText("Reproduciendo vaca");
            }
        });
        animal8 = findViewById(R.id.imageButton8);
        animal8.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity3.this,R.raw.cebra);
                reproductor.start();
                Estatuss.setText("Reproduciendo cebra");
            }
        });
        animal9 = findViewById(R.id.imageButton9);
        animal9.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity3.this,R.raw.mono);
                reproductor.start();
                Estatuss.setText("Reproduciendo mono");
            }
        });
        animal10 = findViewById(R.id.imageButton10);
        animal10.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                DetenerReproductor();
                reproductor = MediaPlayer.create(MainActivity3.this,R.raw.murcielago);
                reproductor.start();
                Estatuss.setText("Reproduciendo murcielago");
            }
        });
    }
    public void DetenerReproductor(){
        if(reproductor!=null){
            if(reproductor.isPlaying()){
                reproductor.release();
                reproductor = null;
            }
        }
    }
}